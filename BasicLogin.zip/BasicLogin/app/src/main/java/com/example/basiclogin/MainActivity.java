package com.example.basiclogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText userNameText ,passwordText;
    Button loginBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userNameText = (EditText) findViewById(R.id.login_username_text);
        passwordText =(EditText) findViewById(R.id.login_password_text);
        loginBtn = findViewById(R.id.btn_login);


        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = userNameText.getText().toString();
                String password = passwordText.getText().toString();
                if (username.equals("admin")&&password.equals("admin")){
                    Toast.makeText(MainActivity.this,"successful",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplicationContext(),newActivity.class);
                    startActivity(intent);

                }
                else{
                    Toast.makeText(MainActivity.this,"Unsuccessful",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}